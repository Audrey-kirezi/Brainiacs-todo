email = "audreykirezi100@gmail.com"

password= "12345"

module.exports.email = email
module.exports.password = password



